# Spark & PDF Extent Report for REST API testing with REST Assured and Cucumber-JVM using JUnit Runner

Refer to this [article](https://ghchirp.online/4199/) and this [repository](https://github.com/grasshopper7/cucumber-rest-assured-extent-report-plugin) for more details.
